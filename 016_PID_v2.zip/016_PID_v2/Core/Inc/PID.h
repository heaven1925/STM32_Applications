/*
 * PID.h
 *
 *  Created on: Jan 1, 2022
 *      Author: atakan
 */

#ifndef INC_PID_H_
#define INC_PID_H_

typedef struct{

	/* CONTROLLER GAINS */
	float Kp;
	float Ki;
	float Kd;
	/* Derivative time const */
	float Td;
	/* Sample Time */
	float T;
	/* Output Limits */
	float limMax;
	float limMin;
	/* Contoller */
	float integrator;
	float differantiator;

	float prevError;
	float prevMeasurement;
	/* Controlled Output */
	float output;

}PID_Controller;


void 	PID_Init(PID_Controller *pid);
float 	PID_Update(PID_Controller *pid, float setPoint, float measurement);



#endif /* INC_PID_H_ */
