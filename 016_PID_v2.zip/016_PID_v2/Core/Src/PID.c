/*
 * PID.c
 *
 *  Created on: Jan 1, 2022
 *      Author: atakan
 */

#include "PID.h"


void 	PID_Init(PID_Controller *pid)
{

	pid -> integrator = 0.0;
	pid -> differantiator = 0.0;

	pid -> prevError = 0.0;
	pid -> prevMeasurement = 0.0;

	pid -> output = 0.0;

	  pid->Kp = 2.0 ;
	  pid->Ki = 0.1 ;
	  pid->Kd = 0.0065 ;
	  pid->T = 1.2;
	  pid->Td = 0.25;

	  pid->limMin = 0.0;
	  pid->limMax = 100.0;

}


float 	PID_Update(PID_Controller *pid, float setPoint, float measurement)
{

	/* Error Signal */

	float error = setPoint - measurement ;

	/* Propotional */
	float proportinal = (pid->Kp) * error;

	/* İntegrator */
	pid->integrator = (pid->integrator) + ( 0.5 * (pid->Ki)  * (pid->Td) * (error - pid->prevError) );

	/* Anti windup integrator limits */
	float limMaxInt, limMinInt;

	if(pid->limMax > proportinal)
		limMaxInt = pid->limMax - proportinal;
	else
		limMaxInt = 0.0;

	if(pid->limMin < proportinal)
		limMinInt = pid->limMin - proportinal;
	else
		limMinInt = 0.0;

	/* Clamp Integrator */
	if(pid->integrator > limMaxInt)
		pid->integrator = limMaxInt;
	else if(pid->integrator < limMinInt)
		pid->integrator = limMinInt;

	/* Derivative Band Limited signal */

	pid->differantiator = 	  (2.0 * pid->Kd * (measurement - pid->prevMeasurement)
							+ (2.0 * pid->Td - pid->T) * pid->differantiator)
							/ (2.0 * pid->Td + pid->T);


	/* Compute Output */

	pid->output = proportinal + pid->integrator + pid->differantiator ;

	if(pid->output > pid->limMax)
		pid->output = pid->limMax;
	else if(pid->output < limMinInt)
		pid->output = pid->limMin;

	/* Store error and measurement */

	pid->prevError = error ;
	pid->prevMeasurement = measurement ;

	/* return controller */
	return pid->output;


}

